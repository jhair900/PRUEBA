// Comparte únicamente análisis idénticos que siguen en curso; cada reintento posterior es nuevo.
(function(global){
  'use strict';
  const pending=new Map();
  function scope(){
    try{return JSON.stringify([JSON.parse(global.localStorage.getItem('autocor_auth')||'null')?.token||'',global.AutoCorConfig?.apiUrl||'']);}
    catch(_){return '';}
  }
  async function share(serializedRequest,work){
    const session=scope();
    let requests=pending.get(session);
    if(!requests){requests=new Map();pending.set(session,requests);}
    // Reutilizar el texto ya preparado evita duplicar los píxeles o buffers del documento.
    let promise=requests.get(serializedRequest);
    if(!promise){promise=Promise.resolve().then(work);requests.set(serializedRequest,promise);}
    try{return structuredClone(await promise);}
    finally{
      if(requests.get(serializedRequest)===promise)requests.delete(serializedRequest);
      if(!requests.size && pending.get(session)===requests)pending.delete(session);
    }
  }
  global.AutoCorDocumentAnalysis={share:share};
})(window);
