const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict'),path=require('node:path');
require('../js/document-processing.js');
const html=fs.readFileSync(path.join(__dirname,'../contratos.html'),'utf8');
const slice=(a,b)=>html.slice(html.indexOf(a),html.indexOf(b,html.indexOf(a)));
function recognition(confidence,evaluate){
 let passes=0;
 const ctx=vm.createContext({spinnerMsg(){},normalizeOcrText:s=>s,scoreOcrText:()=>180,
  OCR_PROFILES:{matricula:{psms:['6','4','11']}},buildOcrCanvases:()=>['original','contraste','binario','otsu','nitido'].map(name=>({name,canvas:{width:100,height:100}})),
  getTesseractWorker:async()=>({setParameters:async()=>{},recognize:async()=>{passes++;return {data:{text:'PLACA ABC1234',confidence,blocks:[]}};}})
 });
 vm.runInContext(slice('function ocrFocusRectangle','async function ocrFilePotenciado'),ctx);
 return {run:()=>ctx.recognizeBestFromCanvas({},'matricula','test',{evaluate}),passes:()=>passes,ctx};
}
(async()=>{
 let r=recognition(95,()=>({pending:[]}));await r.run();assert.equal(r.passes(),1);
 r=recognition(95,()=>({pending:['motor']}));await r.run();assert.equal(r.passes(),3);
 r=recognition(40,()=>({pending:[]}));await r.run();assert.equal(r.passes(),15);
 console.log('OK una pasada si campos comprobados, meseta fiable queda pendiente, baja confianza conserva las 15 alternativas');
 const focus={blocks:[{paragraphs:[{lines:[{text:'MOTOR',confidence:95,bbox:{x0:10,y0:100,x1:100,y1:120}}]}]}]};
 assert.ok(r.ctx.ocrFocusRectangle(focus,['motor'],{width:1000,height:600}));
 assert.equal(r.ctx.ocrFocusRectangle(focus,['motor','chasis'],{width:1000,height:600}),null);
 assert.equal(r.ctx.ocrFocusRectangle({blocks:[]},['motor'],{width:1000,height:600}),null);
 console.log('OK zonas adicionales solo con una etiqueta localizada, sin cortar columnas ni usar coordenadas fijas');
 let calls=0;
 const detected={cedulaRuc:'ID',chasis:'VIN',motor:'MOTOR'};
 const ctx=vm.createContext({spinnerMsg(){},tipoLabel:x=>x,prepararImagenParaIA:async()=>'',analizarConGeminiCampos:async()=>({...detected}),
  ocrFilePotenciado:async()=>{calls++;return 'FULL';},normalizeFieldValue:(k,v)=>v||'',sanitizeDetectedData:x=>x,postProcesarMatriculaConfiabilidad:x=>x,validarCedulaMatriculaPorOCR:()=>({ok:true})});
 vm.runInContext(slice('function isFieldEmpty(', '/* ── Inicializar mapa'),ctx);
 vm.runInContext(slice('function mergearDatosConOCR(', '/* ── Cédula'),ctx);
 const fieldsFn=()=>Object.keys(detected).map(key=>({key}));
 const d=await ctx.procesarIaFirst({file:{name:'front.png'},ocrFiles:[{file:{name:'front.png'}},{file:{name:'back.png'}}],attachments:'test',tipo:'matricula',tipoIA:'matricula',fieldsFn,parserLocal:()=>({...detected})});
 assert.equal(calls,1);assert.deepEqual(Array.from(d._verifiedCritical),['cedulaRuc','chasis','motor']);
 const bad=await ctx.procesarIaFirst({file:{name:'test.png'},tipo:'matricula',tipoIA:'matricula',fieldsFn,parserLocal:()=>({...detected,motor:'OTRO'})});
 assert.equal(bad._origins.motor,'review');
 console.log('OK reevalúa después de cada cara; no omite comprobación de cédula/RUC, chasis o motor y no confirma discrepancias');
 const op=global.AutoCorDocumentProcessing.createOperation({documentType:'matricula',budgets:{totalMs:1000}});
 let cancelRender=0,cleaned=0,destroyed=0,rendering;
 const native='PLACA ABC1234\nPROPIETARIO PERSONA DE PRUEBA\nCHASIS 12345678901234567\nMOTOR 12345678\nMARCA TOYOTA';
 const ex=require('../js/document-extraction.js');
 const pdfCtx=vm.createContext({performance,AutoCorDocumentProcessing:global.AutoCorDocumentProcessing,AutoCorDocumentExtraction:ex,OCR_MAX_PDF_PAGES:{default:6},normalizeOcrText:s=>s,spinnerMsg(){},
  pdfjsLib:{getDocument:()=>({promise:Promise.resolve({numPages:2,getPage:async n=>({getTextContent:async()=>({items:[{str:n===1?native:'encabezado',transform:[1,0,0,1,0,0]}]}),getViewport:()=>({width:200,height:200}),render:()=>({promise:new Promise(()=>{rendering=true;}),cancel:()=>cancelRender++}),cleanup:()=>cleaned++}),destroy:async()=>destroyed++})})},
  document:{createElement:()=>({getContext:()=>({})})}
 });
 vm.runInContext(slice('async function ocrFilePotenciado','/* ── Render PDF page'),pdfCtx);
 const reading=pdfCtx.ocrFilePotenciado({name:'mixed.pdf',arrayBuffer:async()=>new ArrayBuffer(0)},'matricula',{operation:op});
 while(!rendering)await new Promise(r=>setImmediate(r));op.cancel();await assert.rejects(reading,e=>e.code==='PROCESSING_CANCELLED');op.finish('cancelled');
 assert.equal(cancelRender,1);assert.equal(cleaned,2);assert.equal(destroyed,1);
 console.log('OK PDF mixto: cancelar render de página escaneada libera páginas, canvas y documento sin perder el texto ya leído');
})().catch(e=>{console.error(e);process.exitCode=1;});
