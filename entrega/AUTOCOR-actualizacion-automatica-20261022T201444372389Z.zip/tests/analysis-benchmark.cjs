// OCR real sobre imágenes sintéticas sin datos personales. Requiere red para Tesseract/idiomas.
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const {chromium}=require('playwright');
const root=path.resolve(__dirname,'..'),baseline=process.argv[2],output=process.argv[3];
const fn=(s,name)=>{const match=s.match(new RegExp('function '+name+'\\([^]*?\\n\\}'));assert.ok(match,name);return match[0];};
(async()=>{
 const browser=await chromium.launch({channel:'msedge',headless:true,args:['--enable-precise-memory-info']});const results=[];
 try{
  for(const [label,folder] of [['before',baseline],['after',root]]){
   if(!folder)continue;
   const html=fs.readFileSync(path.join(folder,'contratos.html'),'utf8');
   const page=await browser.newPage();
   await page.goto('https://example.com');
   await page.addScriptTag({url:'https://unpkg.com/tesseract.js@5/dist/tesseract.min.js'});
   await page.addScriptTag({content:html.slice(html.indexOf('const OCR_MIN_WIDTH'),html.indexOf('async function limitarPrintPegado'))});
   const normalizers=['normalizeOcrText','normalizeForParsing','scoreOcrText','trimUpper','normalizePlaca','normalizeDate','validarCedulaEc','normalizeCedula10','normalizeRuc13','normalizeIdentificacion','matriculaHasPhoneContext','matriculaHasCedulaContext','findMatriculaCedulaContextual','etqMatr','parseMatricula'];
   await page.addScriptTag({content:normalizers.map(n=>fn(html,n)).join('\n')});
   const first=html.includes('function ocrFocusRectangle')?'function ocrFocusRectangle':'async function recognizeBestFromCanvas';
   await page.addScriptTag({content:html.slice(html.indexOf(first),html.indexOf('async function ocrFilePotenciado'))});
   const report=await page.evaluate(async label=>{
    window.spinnerMsg=()=>{};window.__calls=0;window.__canvases=[];window.__peakPixels=0;window.__peakHeap=0;
    const create=document.createElement.bind(document);
    document.createElement=function(name,...args){const value=create(name,...args);if(name==='canvas')window.__canvases.push(value);return value;};
    const sample=()=>{window.__peakPixels=Math.max(window.__peakPixels,window.__canvases.reduce((n,c)=>n+c.width*c.height,0));window.__peakHeap=Math.max(window.__peakHeap,performance.memory?.usedJSHeapSize||0);};
    const initialized=performance.now();
    const worker=await Tesseract.createWorker(['spa','eng'],1);
    const initMs=Math.round(performance.now()-initialized);
    await worker.setParameters({tessedit_ocr_engine_mode:'1',preserve_interword_spaces:'1',user_defined_dpi:'300'});
    window.getTesseractWorker=async()=>({setParameters:p=>worker.setParameters(p),recognize:async(c,o)=>{window.__calls++;sample();const result=await worker.recognize(c,o,{blocks:true});sample();return result;}});
    const reports=[];
    try{
     for(const fixture of ['short-clear','short-degraded','missing-motor']){
      window.__peakPixels=0;window.__peakHeap=0;
      const canvas=document.createElement('canvas');canvas.width=1200;canvas.height=380;
      const c=canvas.getContext('2d');c.fillStyle='#fff';c.fillRect(0,0,1200,380);
      c.fillStyle=fixture==='short-degraded'?'#a8a8a8':'#000';c.font='36px Arial';
      const chasis=fixture==='short-degraded'?'1HGBH41JXMN109186':'12345678901234567';
      const rows=['PLACA: ABC1234','CHASIS: '+chasis];if(fixture!=='missing-motor')rows.push('MOTOR: 12345678');
      if(fixture==='short-degraded'){c.translate(20,0);c.rotate(.025);c.filter='blur(1.2px)';}
      rows.forEach((text,i)=>c.fillText(text,55,80+i*90));
      const expected={placa:'ABC1234',chasis,motor:'12345678'};
      const options={evaluate:text=>{const d=parseMatricula(text);return {pending:Object.keys(expected).filter(k=>d[k]!==expected[k]||(d._reviewKeys||[]).includes(k))};}};
      const start=performance.now(),before=window.__calls,heapTimer=setInterval(sample,50);
      const text=await recognizeBestFromCanvas(canvas,'matricula',fixture,options),d=parseMatricula(text);
      clearInterval(heapTimer);sample();
      const present=Object.keys(expected).filter(k=>fixture!=='missing-motor'||k!=='motor');
      const correct=present.filter(k=>d[k]===expected[k]&&!(d._reviewKeys||[]).includes(k)).length;
      reports.push({version:label,fixture,elapsedMs:Math.round(performance.now()-start),passes:window.__calls-before,fields:present.length,correct,pending:3-correct,aiCalls:0,inputPixels:canvas.width*canvas.height,initMs,maxLiveCanvasPixels:window.__peakPixels,peakPageJsHeapBytes:window.__peakHeap});
      canvas.width=canvas.height=0;
     }
    }finally{await worker.terminate();}
    return reports;
   },label);
   results.push(...report);await page.close();
  }
 }finally{await browser.close();}
 const report={kind:'real-tesseract-synthetic-images',production:false,results};
 if(output)fs.writeFileSync(output,JSON.stringify(report,null,2)+'\n');
 console.log(JSON.stringify(report,null,2));
})().catch(e=>{console.error(e);process.exitCode=1;});
