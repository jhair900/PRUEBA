const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict');
require('../js/document-processing.js');
const html=fs.readFileSync(path.join(__dirname,'../contratos.html'),'utf8');
function setup(statuses,budgets={}){
 let clock=0;const calls=[];
 const clockDate=class extends Date{static now(){return clock;}};
 const win={AutoCorProcessingBudgets:budgets};
 const ctx=vm.createContext({window:win,AutoCorDocumentProcessing:global.AutoCorDocumentProcessing,Date:clockDate,Map,Set,Promise,console:{warn(){}},AutoCorConfig:{apiUrl:'https://example.test'},sessionStorage:{getItem:()=>null,setItem(){}},setAIBanner(){},aiAvailable:false,
 AutoCorGemini:{fetch:async(url,init,timeout,trace)=>{
  calls.push({url,timeout});trace.transport='fetch';
  if(timeout<15){clock+=timeout;const e=new Error('timeout');e.code='AI_TIMEOUT';throw e;}
  clock+=15;const item=statuses.shift();
  if(item instanceof Error)throw item;
  return {ok:item===200,status:item,json:async()=>({candidates:[]}),text:async()=>'{"error":"provider message must never enter diagnostics"}'};
 }}});
 vm.runInContext(html.slice(html.indexOf('const GEMINI_MODEL_CATALOG'),html.indexOf('/* Los criterios de extracción')),ctx);
 vm.runInContext(html.slice(html.indexOf('function restoreGeminiCooldowns'),html.indexOf('window.testAIConnection')),ctx);
 return {ctx,calls,clock:()=>clock};
}
(async()=>{
 let t=setup([429,429,429,200],{maxModelAttempts:2});
 await assert.rejects(()=>t.ctx.geminiGenerateWithFallback({contents:[]}),e=>e.code==='AI_QUOTA_EXHAUSTED'&&e.analysisAttempts.length===2);assert.equal(t.calls.length,2);
 t=setup([429,429,200],{aiMs:35,aiAttemptMs:30,maxModelAttempts:3});
 await assert.rejects(()=>t.ctx.geminiGenerateWithFallback({contents:[]}),e=>e.code==='AI_TIMEOUT');assert.equal(t.clock(),35);assert.deepEqual(t.calls.map(c=>c.timeout),[30,20,5]);
 console.log('OK presupuesto IA compartido entre modelos, máximo de intentos y espera restante');
 for(const [status,code] of [[401,'AI_AUTH_ERROR'],[403,'AI_AUTH_ERROR'],[500,'AI_UPSTREAM_ERROR'],[400,'AI_REQUEST_REJECTED']]){
  t=setup([status,200]);await assert.rejects(()=>t.ctx.geminiGenerateWithFallback({}),e=>e.code===code);assert.equal(t.calls.length,1);
 }
 const network=new Error('red');network.code='AI_NETWORK_ERROR';t=setup([network,200]);await assert.rejects(()=>t.ctx.geminiGenerateWithFallback({}),e=>e.code==='AI_NETWORK_ERROR');assert.equal(t.calls.length,1);
 t=setup([404,200]);assert.ok((await t.ctx.geminiGenerateWithFallback({})).model);assert.equal(t.calls.length,2);
 const c=new AbortController();c.abort();t=setup([200]);await assert.rejects(()=>t.ctx.geminiGenerateWithFallback({},{signal:c.signal}),e=>e.code==='AI_CANCELLED');assert.equal(t.calls.length,0);
 console.log('OK autorización/red no reenvían; modelo inexistente permite alternativa; cancelar evita nuevos envíos');
})().catch(e=>{console.error(e);process.exitCode=1;});
