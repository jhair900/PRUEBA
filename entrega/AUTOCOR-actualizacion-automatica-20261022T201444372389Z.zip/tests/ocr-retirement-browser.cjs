// Recuperación real de la interfaz; Gemini y Tesseract son dobles controlados.
const {chromium}=require('playwright');
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const root=path.resolve(__dirname,'..');
(async()=>{
 const browser=await chromium.launch({channel:'msedge',headless:true});
 try{
  for(const scenario of ['rejected','never','cancel-rejected','cancel-never']){
   const page=await browser.newPage({viewport:{width:1100,height:820}}),errors=[];
   page.on('pageerror',e=>errors.push(e.message));page.on('dialog',d=>d.accept());
   await page.route('**/*',r=>{
    const url=new URL(r.request().url());if(url.hostname!=='autocor.test')return r.abort();
    const file=path.join(root,decodeURIComponent(url.pathname));
    if(url.pathname==='/js/api-client.js')return r.fulfill({contentType:'application/javascript',body:'window.AutoCorApi={postJson:async()=>({ok:true,rows:[]})};'});
    if(!file.startsWith(root+path.sep)||!fs.existsSync(file))return r.fulfill({status:404,body:''});
    return r.fulfill({contentType:file.endsWith('.html')?'text/html':file.endsWith('.js')?'application/javascript':file.endsWith('.css')?'text/css':'image/png',body:fs.readFileSync(file)});
   });
   await page.addInitScript(()=>{try{localStorage.setItem('autocor_auth',JSON.stringify({user:'PRUEBA',token:'simulado',isAdmin:true}));}catch(_){}window.__unhandled=[];window.addEventListener('unhandledrejection',e=>window.__unhandled.push(e.reason?.code||'UNHANDLED'));});
   await page.goto('https://autocor.test/contratos.html');
   await page.evaluate(scenario=>{
    window.AutoCorProcessingBudgets={totalMs:8000,ocrMs:6500,ocrPassMs:scenario.startsWith('cancel')?5000:40,ocrInitMs:1000};
    window.__trace=[];addEventListener('autocor-timing',e=>window.__trace.push(e.detail));
    window.__workers=0;window.__terminated=0;window.__ocr=0;window.__ai=0;
    AutoCorGemini.fetch=async()=>{window.__ai++;return {ok:true,status:200,json:async()=>({candidates:[{finishReason:'STOP',content:{parts:[{text:'{}'}]}}]})};};
    window.Tesseract={createWorker:async()=>{window.__workers++;return {setParameters:async()=>{},recognize:()=>{window.__ocr++;return new Promise(()=>{});},terminate:()=>{window.__terminated++;return scenario.endsWith('rejected')?Promise.reject(new TypeError('CONTENIDO DOCUMENTAL PRIVADO')):new Promise(()=>{});}};}};
    _contratosData.matricula={placa:'MANUAL',modelo:'',_origins:{placa:'manual',modelo:'manual'}};
    const canvas=document.createElement('canvas');canvas.width=800;canvas.height=500;
    canvas.getContext('2d').fillRect(0,0,800,500);
    const bytes=Uint8Array.from(atob(canvas.toDataURL().split(',')[1]),c=>c.charCodeAt(0));
    onFileChange({target:{files:[new File([bytes],'prueba.png',{type:'image/png'})]}},'matricula');
   },scenario);
   await page.waitForFunction(()=>window.__ocr===1);
   if(scenario.startsWith('cancel')){
    await page.getByRole('button',{name:'Cancelar procesamiento',exact:true}).click();
    await page.waitForFunction(()=>!document.getElementById('spinnerOverlay').classList.contains('open'));
    // La notificación tardía de terminate no debe volver a aplicar el parcial.
    await page.evaluate(()=>{_contratosData.matricula.placa='EDICION POSTERIOR';_contratosData.matricula.modelo='';_contratosData.matricula._origins.modelo='manual';});
   }
   await page.waitForFunction(()=>document.getElementById('documentRecoveryText').textContent.includes('Guarda un borrador y recarga'),null,{timeout:10000});
   await page.waitForFunction(()=>!document.getElementById('spinnerOverlay').classList.contains('open'));
   assert.equal(await page.getByRole('button',{name:'Reintentar documento',exact:true}).isDisabled(),true);
   assert.equal(await page.getByRole('button',{name:'Revisar datos',exact:true}).isVisible(),true);
   assert.equal(await page.evaluate(()=>_contratosData.matricula.placa),scenario.startsWith('cancel')?'EDICION POSTERIOR':'MANUAL');
   assert.equal(await page.evaluate(()=>_contratosData.matricula.modelo),'');
   const before=await page.evaluate(()=>window.__ai);
   await page.evaluate(()=>{retryDocumentProcessing('matricula');retryDocumentProcessing();});
   await page.waitForTimeout(60);
   assert.deepEqual(await page.evaluate(()=>[window.__workers,window.__terminated,window.__ai]),[1,1,before]);
   const traces=await page.evaluate(()=>JSON.stringify(window.__trace));
   assert.ok(traces.includes('OCR_RESTART_REQUIRED'));assert.ok(traces.includes(scenario.endsWith('rejected')?'OCR_TERMINATION_REJECTED':'OCR_TERMINATION_TIMEOUT'));assert.ok(!traces.includes('CONTENIDO DOCUMENTAL PRIVADO'));
   assert.deepEqual(await page.evaluate(()=>window.__unhandled),[]);assert.deepEqual(errors,[]);
   await page.getByRole('button',{name:'Revisar datos',exact:true}).click();
   assert.equal(await page.evaluate(()=>document.getElementById('documentRecovery').hidden),true);
   assert.equal(await page.evaluate(()=>_contratosData.matricula._origins.modelo),'manual');
   console.log('OK navegador '+scenario+': guardar borrador/recargar, revisión disponible, manuales protegidos, un worker y cero rechazos sin manejar');
   await page.close();
  }
 }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
