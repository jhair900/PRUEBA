const assert=require('node:assert/strict');
require('../js/document-processing.js');const api=global.AutoCorDocumentProcessing;
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const unhandled=[];const listener=e=>unhandled.push(e);process.on('unhandledRejection',listener);
(async()=>{
 try{
  for(const mode of ['rejected','never']){
   let created=0,terminated=0;const events=[];
   const cause=new TypeError('CONTENIDO DOCUMENTAL PRIVADO');
   const engine=api.createOcrEngine(async()=>{created++;return {setParameters:async()=>{},recognize:()=>new Promise(()=>{}),terminate:()=>{terminated++;return mode==='rejected'?Promise.reject(cause):new Promise(()=>{});}};},{onRestartRequired:(e,op)=>events.push({e,op})});
   const first=api.createOperation({documentType:'matricula',budgets:{totalMs:6000,ocrPassMs:10}});
   let failure;try{await engine.use(first,run=>run({},{}));}catch(e){failure=e;}finally{first.finish('failed');}
   await sleep(10);
   assert.equal(failure?.code,'OCR_RESTART_REQUIRED',mode+' normaliza el error');
   if(mode==='rejected')assert.equal(failure.cause,cause);else assert.equal(failure.cause.code,'OCR_TERMINATION_TIMEOUT');
   assert.equal(events.length,1,'Notifica una vez la recuperación imposible');assert.equal(events[0].op,first);
   assert.ok(!JSON.stringify(first.details).includes('CONTENIDO DOCUMENTAL PRIVADO'));
   const second=api.createOperation({documentType:'matricula',budgets:{totalMs:1000}});
   try{await assert.rejects(engine.use(second,run=>run({},{})),e=>e.code==='OCR_RESTART_REQUIRED'&&e.cause===failure.cause);}finally{second.finish('failed');}
   await assert.rejects(engine.retire(),e=>e.code==='OCR_RESTART_REQUIRED');
   assert.equal(created,1);assert.equal(terminated,1);await sleep(10);assert.deepEqual(unhandled,[]);
   console.log('OK terminate '+mode+': estado normalizado, causa interna, sin rechazos no manejados ni workers adicionales');
  }
 }finally{process.removeListener('unhandledRejection',listener);}
})().catch(e=>{console.error(e);process.exitCode=1;});
