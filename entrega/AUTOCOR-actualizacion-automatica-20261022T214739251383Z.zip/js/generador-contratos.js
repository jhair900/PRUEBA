/* ══════════════════════════════════════════════════════════════════
   generador-contratos.js  —  Generación de contratos Word desde
   los datos validados en contratos.html
   Requiere: PizZip, docxtemplater, contrato-templates.js
   ══════════════════════════════════════════════════════════════════ */
(function(global){
  'use strict';

  /* ── Utilidades ──────────────────────────────────────────────── */

  const MESES = ['enero','febrero','marzo','abril','mayo','junio',
                 'julio','agosto','septiembre','octubre','noviembre','diciembre'];

  function fechaHoy(){
    var d = new Date();
    return {
      dia:  String(d.getDate()).padStart(2,'0'),
      mes:  MESES[d.getMonth()],
      anio: String(d.getFullYear())
    };
  }

  function numeroATexto(n){
    // Convierte un entero validado a texto en español (hasta 999 999 999).
    var unidades = ['','uno','dos','tres','cuatro','cinco','seis','siete','ocho','nueve',
                    'diez','once','doce','trece','catorce','quince','dieciséis','diecisiete',
                    'dieciocho','diecinueve','veinte','veintiuno','veintidós','veintitrés',
                    'veinticuatro','veinticinco','veintiséis','veintisiete','veintiocho','veintinueve'];
    var decenas = ['','','veinte','treinta','cuarenta','cincuenta','sesenta','setenta','ochenta','noventa'];
    var centenas = ['','ciento','doscientos','trescientos','cuatrocientos','quinientos',
                    'seiscientos','setecientos','ochocientos','novecientos'];
    function menorMil(x){
      if(x===0) return '';
      if(x===100) return 'cien';
      if(x<30) return unidades[x];
      if(x<100){
        var d=Math.floor(x/10), u=x%10;
        return u===0 ? decenas[d] : decenas[d]+' y '+unidades[u];
      }
      var c=Math.floor(x/100), r=x%100;
      return centenas[c]+(r>0?' '+menorMil(r):'');
    }
    function apocopar(txt){
      return txt.replace(/veintiuno$/, 'veintiún').replace(/uno$/, 'un');
    }
    function menorMillon(x){
      var miles = Math.floor(x/1000), resto = x%1000;
      var txt = miles===1 ? 'mil' : (miles>1 ? apocopar(menorMil(miles))+' mil' : '');
      if(resto>0) txt += (txt?' ':'')+menorMil(resto);
      return txt;
    }
    if(!Number.isSafeInteger(n) || n<0 || n>999999999){
      throw new Error('El valor estimado debe ser menor a 1.000.000.000.');
    }
    if(n===0) return 'CERO';
    var millones = Math.floor(n/1000000), resto = n%1000000;
    var txt = millones===1 ? 'un millón' : (millones>1 ? apocopar(menorMil(millones))+' millones' : '');
    if(resto>0) txt += (txt?' ':'')+menorMillon(resto);
    return apocopar(txt).toUpperCase();
  }

  function interpretarValorContrato(valor){
    var errorFormato = 'Revisa el valor estimado. Usa, por ejemplo, 19599,65 o 19.599,65, con máximo dos decimales.';
    var raw = String(valor == null ? '' : valor).trim();
    if(typeof valor === 'number'){
      // Un número ya tiene decimal de JavaScript: nunca tratarlo como miles.
      if(!Number.isFinite(valor) || valor<0 || valor>=1000000000) throw new Error(errorFormato);
      if(Math.abs(valor*100-Math.round(valor*100))>0.00001) throw new Error(errorFormato);
      raw = valor.toFixed(2);
    }
    // Aceptar coma o punto decimal y agrupaciones de miles consistentes.
    // Separar dólares y centavos como dígitos evita perder o redondear decimales.
    var partes = raw.match(/^(\d+|\d{1,3}(?:\.\d{3})+)(?:,(\d{1,2}))?$/)
      || raw.match(/^(\d+|\d{1,3}(?:,\d{3})+)(?:\.(\d{1,2}))?$/);
    if(!partes) throw new Error(errorFormato);
    var entero = Number(partes[1].replace(/[.,]/g,''));
    if(!Number.isSafeInteger(entero) || entero>999999999){
      throw new Error('El valor estimado debe ser menor a 1.000.000.000.');
    }
    var centavos = (partes[2] || '').padEnd(2,'0');
    return {entero:entero, centavos:centavos, numero:String(entero)+','+centavos};
  }

  function valorInterpretadoATexto(valor){
    var txt = numeroATexto(valor.entero);
    if(valor.centavos!=='00') txt += ' CON '+valor.centavos+'/100';
    return txt;
  }

  function valorATexto(valor){
    return valorInterpretadoATexto(interpretarValorContrato(valor));
  }

  function normalizarNombre(nombre){
    return String(nombre||'').normalize('NFC').toUpperCase().trim();
  }

  function normalizarEstadoCivil(estadoCivil){
    var valor = normalizarNombre(estadoCivil);
    var clave = valor.normalize('NFD').replace(/[\u0300-\u036f]/g, '');
    return clave === 'UNION LIBRE' || clave === 'UNION DE HECHO'
      ? 'UNION DE HECHO'
      : valor;
  }

  /* ── Recopilar datos validados ───────────────────────────────── */

  function recopilarDatos(extra){
    var ciudadContrato = String(extra.domicilio || '').trim().toUpperCase();
    var firmaIntermediario = ciudadContrato === 'GUAYAQUIL'
      ? 'AUTOCOR-AUTOPLAZA S.A.S.'
      : ciudadContrato === 'QUITO' ? 'AUTOCOR AUTOEVOLUCION S.A.S.' : '';
    if(!firmaIntermediario){
      throw new Error('Selecciona Quito o Guayaquil para asignar el pie de firma del intermediario.');
    }
    var datos = global._contratosData || {};
    var flujo = global._contratosFlujo || {};
    var esJuridica = flujo.tipoPersona === 'juridica';
    var ruc  = datos['ruc']          || {};
    var ced  = datos['cedula-prop'] || {};
    var cony = datos['cedula-cony'] || {};
    var cuv  = datos['cuv']         || {};
    var matr = datos['matricula']   || {};
    var not  = datos['notaria']     || {};

    // Nombre propietario: apellidos + nombres
    var apellidos = ced.apellidos || '';
    var nombres   = ced.nombres   || '';
    var nombreProp = apellidos && nombres
      ? normalizarNombre(apellidos + ' ' + nombres)
      : normalizarNombre(ced.propietario || cuv.propietario || matr.propietario || '');

    // Datos vehículo: prioridad cuv > matrícula > notaría
    // Busca el campo en las tres fuentes con múltiples nombres alternativos
    function pick(){
      var campos = Array.prototype.slice.call(arguments);
      var fuentes = [cuv, matr, not];
      for(var fi=0; fi<fuentes.length; fi++){
        var src = fuentes[fi] || {};
        for(var ci=0; ci<campos.length; ci++){
          var v = src[campos[ci]];
          if(v && String(v).trim()) return String(v).trim();
        }
      }
      return '';
    }

    var placa   = pick('placa');
    var marca   = pick('marca');
    var modelo  = pick('modelo');
    var color   = pick('color');
    var anio    = pick('anio');
    var chasis  = pick('chasis', 'serialChasis', 'vin');
    var motor   = pick('motor', 'numeroMotor');

    var estadoCivil = normalizarEstadoCivil(
      (!esJuridica && flujo.estadoCivil) || ced.estadoCivil || cuv.estadoCivil || matr.estadoCivil || ''
    );
    var nacionalidad = normalizarNombre(
      ced.nacionalidad || cuv.nacionalidad || matr.nacionalidad || 'ECUATORIANA'
    );
    var ciProp = ced.numeroCedula || ced.cedulaRuc || cuv.cedula || matr.cedulaRuc || '';

    // Cónyuge
    var nombreCony = '';
    var ciCony = '';
    var nacionalidadCony = 'ECUATORIANA';
    if(cony && (cony.apellidos || cony.nombres || cony.propietario)){
      var capCony = cony.apellidos || '';
      var nomCony = cony.nombres   || '';
      nombreCony = capCony && nomCony
        ? normalizarNombre(capCony+' '+nomCony)
        : normalizarNombre(cony.propietario || '');
      ciCony = cony.numeroCedula || cony.cedulaRuc || '';
      nacionalidadCony = normalizarNombre(cony.nacionalidad || 'ECUATORIANA');
    }

    var fecha = fechaHoy();

    // La cifra y las letras provienen del mismo valor, interpretado una sola vez.
    var valor = String(extra.valorNum == null ? '' : extra.valorNum).trim()
      ? interpretarValorContrato(extra.valorNum) : null;
    var valorText = valor ? valorInterpretadoATexto(valor) : '';
    var valorDisp = valor ? valor.numero : '';

    var representanteLegal = nombreProp || ruc.representanteLegal || '';
    var razonSocial = normalizarNombre(ruc.razonSocial || ruc.nombreComercial || '');
    var numeroRuc = ruc.numeroRuc || '';
    var nombrePropFmt = esJuridica ? (razonSocial || '___________________') : (nombreProp || '___________________');
    return {
      NOMBRE_PROP:          nombrePropFmt,
      CI_PROP:              ciProp     || '___________',
      ESTADO_CIVIL_PROP:    estadoCivil|| '___________',
      NACIONALIDAD_PROP:    nacionalidad,
      DOMICILIO_PROP:       String(extra.domicilio || '').trim(),
      INTERMEDIARIO_FIRMA:  firmaIntermediario,
      TELEFONO_PROP:        extra.telefonoProp || '___________',
      EMAIL_PROP:           extra.emailProp    || '___________',

      NOMBRE_CONY:          nombreCony         || '___________________',
      CI_CONY:              ciCony             || '___________',
      NACIONALIDAD_CONY:    nacionalidadCony,
      TELEFONO_CONY:        extra.telefonoCony || '___________',
      EMAIL_CONY:           extra.emailCony    || '___________',

      PLACA:                placa   || '___________',
      PLACA_SIN_GUION:      placa ? placa.replace(/[^A-Za-z0-9]/g, '') : '_________',
      MARCA:                marca   || '___________',
      MODELO:               modelo  || '___________',
      COLOR:                color   || '___________',
      ANIO:                 anio    || '____',
      CHASIS:               chasis  || '___________________',
      MOTOR:                motor   || '___________________',
      KM:                   extra.km        || '______',
      VALOR_NUM:            valorDisp       || '___________',
      VALOR_TEXT:           valorText       || '___________',
      CODIGO_ENCARGO:       'AC - '+(placa||'_________'),

      DOMICILIO_GENERADOR:  'AV. 6 DE DICIEMBRE Y SANTA LUCIA, QUITO',
      EMAIL_GENERADOR:      'vllugcha@autocor.com.ec',
      EMAIL_FIDUCIARIA:     'infouio@anefi.com.ec',

      FECHA_DIA:            extra.fechaDia  || fecha.dia,
      FECHA_MES:            extra.fechaMes  || fecha.mes,
      FECHA_ANIO:           extra.fechaAnio || fecha.anio,
      FECHA_CONTRATO_DIA:   extra.fechaDia  || fecha.dia,
      FECHA_CONTRATO_MES:   extra.fechaMes  || fecha.mes,
      FECHA_CONTRATO_ANIO:  extra.fechaAnio || fecha.anio,
      ESTADO_CIVIL_PROP_MINUSCULA: (estadoCivil || '___________').toLowerCase(),
      RAZON_SOCIAL:         razonSocial         || '___________________',
      RUC:                  numeroRuc           || '_____________',
      REPRESENTANTE_LEGAL: representanteLegal  || '___________________',
      CI_REPRESENTANTE:     ciProp              || '___________',
      ESTADO_CIVIL_REP:     estadoCivil         || '___________',
      TIPO_OPERACION:       flujo.operacion     || 'compra_directa',
      TIPO_PERSONA:         flujo.tipoPersona   || 'natural',
    };
  }

  /* ── Selección de plantilla ──────────────────────────────────── */

  function esPlantillaCasados(estadoCivil){
    var ec = String(estadoCivil||'').toUpperCase().trim();
    return ec === 'CASADO' || ec === 'CASADA'
        || ec === 'UNION LIBRE' || ec === 'UNIÓN LIBRE'
        || ec === 'UNION DE HECHO' || ec === 'UNIÓN DE HECHO';
  }

  /* ── Generar docx con docxtemplater ─────────────────────────── */

  function generarDocx(templateBase64, variables){
    var binStr = atob(templateBase64);
    var bytes  = new Uint8Array(binStr.length);
    for(var i=0;i<binStr.length;i++) bytes[i]=binStr.charCodeAt(i);

    // docxtemplater se expone como window.docxtemplater o window.Docxtemplater según la versión del build
    var DocxTpl = global.Docxtemplater || global.docxtemplater;
    if(!DocxTpl) throw new Error('Librería docxtemplater no cargada.');
    if(!global.PizZip)  throw new Error('Librería PizZip no cargada.');

    var zip = new global.PizZip(bytes.buffer);
    var doc = new DocxTpl(zip, {
      paragraphLoop: true,
      linebreaks: true,
      delimiters: { start: '{', end: '}' }
    });
    doc.setData(variables);
    try {
      doc.render();
    } catch(e){
      console.error('[Contratos] Error docxtemplater:', e);
      throw new Error('Error al generar el contrato: '+e.message);
    }
    return doc.getZip().generate({ type:'arraybuffer' });
  }

  function descargarDocx(buffer, nombreArchivo){
    var blob = new Blob([buffer], {
      type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    });
    var url  = URL.createObjectURL(blob);
    var a    = document.createElement('a');
    a.href   = url;
    a.download = nombreArchivo;
    document.body.appendChild(a);
    a.click();
    setTimeout(function(){ URL.revokeObjectURL(url); a.remove(); }, 2000);
  }

  /* ── Función principal ───────────────────────────────────────── */

  function generarContratos(extra, options){
    options = options || {};
    var templates = global.CONTRATO_TEMPLATES;
    if(!templates){
      throw new Error('Plantillas no cargadas. Asegúrate de incluir contrato-templates.js.');
    }
    if(!global.PizZip || (!global.Docxtemplater && !global.docxtemplater)){
      throw new Error('Faltan librerías PizZip / Docxtemplater. Verifica la conexión a internet para cargar las CDN.');
    }

    var vars      = recopilarDatos(extra);
    var juridica  = vars.TIPO_PERSONA === 'juridica';
    var comision  = vars.TIPO_OPERACION === 'comision';
    var casado    = !juridica && esPlantillaCasados(vars.ESTADO_CIVIL_PROP);
    var encKey    = juridica ? 'encargo-juridica' : (casado ? 'encargo-casado' : 'encargo-soltero');
    var preKey;
    if(juridica){
      preKey = comision ? 'prestacion-juridica-comision' : 'prestacion-juridica-directa';
    }else if(comision){
      preKey = casado ? 'prestacion-comision-casado' : 'prestacion-comision-soltero';
    }else{
      preKey = casado ? 'prestacion-casado' : 'prestacion-soltero';
    }
    if(!templates[preKey] || (!juridica && !templates[encKey])){
      throw new Error('No se encontraron las plantillas Dilileg para el flujo seleccionado.');
    }
    var fecha  = vars.FECHA_DIA+'-'+vars.FECHA_MES.substring(0,3).toUpperCase()+'-'+vars.FECHA_ANIO;
    var placa  = vars.PLACA.replace(/[^A-Z0-9]/gi,'') || 'CONTRATO';

    console.log('[Contratos] Generando para', vars.NOMBRE_PROP, '| Persona:', vars.TIPO_PERSONA, '| Operación:', vars.TIPO_OPERACION, '| Prestación:', preKey);

    var generados = [];

    // 1. Encargo Fiduciario correspondiente al tipo de persona.
    if(templates[encKey]){
      var bufEnc = generarDocx(templates[encKey], vars);
      var nomEnc = 'Encargo_Fiduciario_'+placa+'_'+fecha+'.docx';
      if(options.download !== false) descargarDocx(bufEnc, nomEnc);
      generados.push({ tipo:'encargo', nombre: nomEnc, buffer: bufEnc, casado: casado });
    }

    // 2. Contrato Prestación de Servicios
    var bufPre = generarDocx(templates[preKey], vars);
    var nomPre = 'Prestacion_Servicios_'+placa+'_'+fecha+'.docx';
    if(options.download !== false) descargarDocx(bufPre, nomPre);
    generados.push({ tipo:'prestacion', nombre: nomPre, buffer: bufPre });

    // Exponer los buffers para que contratos.html pueda subirlos a Drive
    try { global._contratosGenerados = { placa: placa, fecha: fecha, generados: generados }; } catch(_){}

    return {
      encargo: templates[encKey] ? encKey : null,
      prestacion: preKey,
      pendienteEncargoJuridico: juridica && !templates[encKey],
      vars: vars,
      generados: generados
    };
  }

  /* Convierte un buffer .docx (Uint8Array) a base64 sin prefijo data: */
  function bufferToBase64(buf){
    var bytes = buf instanceof Uint8Array ? buf : new Uint8Array(buf);
    var bin = '';
    var chunk = 0x8000;
    for(var i=0; i<bytes.length; i+=chunk){
      bin += String.fromCharCode.apply(null, bytes.subarray(i, i+chunk));
    }
    return btoa(bin);
  }

  /* ── Exponer ─────────────────────────────────────────────────── */
  global.generarContratos     = generarContratos;
  global.descargarContratosGenerados = function(result){ (result.generados || []).forEach(function(g){ descargarDocx(g.buffer, g.nombre); }); };
  global._valorATextoHelper   = valorATexto;
  global._docxBufferToBase64  = bufferToBase64;

})(window);
