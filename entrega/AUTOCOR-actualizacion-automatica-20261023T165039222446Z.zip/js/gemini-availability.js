/* Disponibilidad activa. Sólo conserva estados y diagnósticos sin documentos. */
(function(root,factory){
  const api=factory();
  if(typeof module==='object'&&module.exports)module.exports=api;else root.AutoCorGeminiAvailability=api;
})(typeof globalThis!=='undefined'?globalThis:this,function(){
  'use strict';
  // IDs contrastados con las fichas oficiales el 22-10-2026. La cuenta se consulta aparte.
  const catalog=Object.freeze([
    {id:'gemini-3.5-flash-lite',label:'Gemini 3.5 Flash Lite'},
    {id:'gemini-3.1-flash-lite',label:'Gemini 3.1 Flash Lite'},
    {id:'gemini-3.8-flash',label:'Gemini 3.8 Flash'},
    {id:'gemini-3-flash-preview',label:'Gemini 3 Flash (Preview)'},
    {id:'gemini-3.6-flash',label:'Gemini 3.6 Flash'},
    {id:'gemini-2.5-flash-lite',label:'Gemini 2.5 Flash Lite'}
  ]);
  const error=code=>Object.assign(new Error(code),{code});
  function wait(work,signal,ms){
    return new Promise((resolve,reject)=>{
      let done=false;
      const finish=(fn,v)=>{if(done)return;done=true;clearTimeout(timer);signal?.removeEventListener('abort',cancel);fn(v);};
      const cancel=()=>finish(reject,error(signal.reason?.code||'AI_CANCELLED'));
      const timer=setTimeout(()=>finish(reject,error('AI_TIMEOUT')),ms);
      if(signal?.aborted){cancel();return;}
      signal?.addEventListener('abort',cancel,{once:true});
      Promise.resolve().then(work).then(v=>finish(resolve,v),e=>finish(reject,e));
    });
  }
  function retryDelay(response,data,now){
    const header=response.retryAfter;
    const seconds=Number(header);
    if(header&&Number.isFinite(seconds))return Math.max(0,seconds*1000);
    if(header&&Number.isFinite(Date.parse(header)))return Math.max(0,Date.parse(header)-now);
    for(const detail of data?.error?.details||[]){
      const match=/^(\d+(?:\.\d+)?)s$/.exec(String(detail.retryDelay||''));
      if(match)return Number(match[1])*1000;
    }
    return 60000;
  }
  function classify(status){return status===401||status===403?'AI_AUTH_ERROR':status===429?'AI_QUOTA_EXHAUSTED':status===404||status===410?'AI_MODEL_UNAVAILABLE':status>=500?'AI_UPSTREAM_ERROR':status===0?'AI_NETWORK_ERROR':'AI_REQUEST_REJECTED';}
  function create(options){
    const now=options.now||Date.now,config={ttlMs:120000,checkMs:45000,attemptMs:10000,maxCandidates:catalog.length,maxCheckRuns:2,retryMs:60000,...options.config};
    config.ttlMs=Math.max(1000,Math.min(300000,config.ttlMs));
    config.maxCandidates=Math.max(1,Math.min(catalog.length,config.maxCandidates));
    config.maxCheckRuns=Math.max(1,Math.min(3,config.maxCheckRuns));
    let context='',epoch=0,active='',lastGood='',checkPromise=null,lastCode='',checkRuns=0,retryAt=0;
    const proofs=new Map(),states=new Map(),controllers=new Set();
    function reset(){epoch++;active=lastGood='';proofs.clear();states.clear();checkPromise=null;lastCode='';checkRuns=retryAt=0;for(const c of controllers)c.abort(error('AI_CONTEXT_CHANGED'));controllers.clear();}
    function sync(){const next=options.getContext();if(next!==context){reset();context=next;}return !!context;}
    function valid(model){const proof=proofs.get(model);return !!proof&&proof.epoch===epoch&&now()<proof.until;}
    function snapshot(){
      sync();const ready=!!active&&valid(active),entry=ready?proofs.get(active):null;
      return {model:ready?active:'',ready,checkedAt:entry?.at||0,expiresAt:entry?.until||0,checking:!!checkPromise,code:lastCode,nextCheckAt:retryAt,retryExhausted:!ready&&!checkPromise&&checkRuns>=config.maxCheckRuns,
        models:catalog.map(m=>({...m,...states.get(m.id),status:valid(m.id)?'available':states.get(m.id)?.status==='available'?'unchecked':states.get(m.id)?.status||'unchecked'}))};
    }
    const emit=()=>options.onState?.(snapshot());
    function guard(tipo){sync();if(tipo==='cuv')return true;if(!active||!valid(active)){emit();throw error('AI_PRECHECK_REQUIRED');}return {epoch,context,model:active};}
    function checkTicket(ticket){sync();if(ticket.epoch!==epoch||ticket.context!==context)throw error('AI_CONTEXT_CHANGED');}
    async function call(model,body,signal,timeoutMs,stage,ticket){
      const start=now(),trace=stage==='ai-precheck'?{selectionRun:checkRuns,attemptBudgetMs:timeoutMs}:{};let code='',status;
      // Cada intento cancela también su transporte; no basta con abandonar su promesa.
      const controller=new AbortController(),cancel=()=>controller.abort(signal.reason||error('AI_CANCELLED'));
      controllers.add(controller);
      if(signal?.aborted)cancel();else signal?.addEventListener('abort',cancel,{once:true});
      const timer=setTimeout(()=>controller.abort(error('AI_TIMEOUT')),timeoutMs);
      try{
        checkTicket(ticket);
        const response=await wait(()=>{if(controller.signal.aborted)throw controller.signal.reason;return options.request(model,body,controller.signal,timeoutMs,trace);},controller.signal,timeoutMs);status=response.status;
        checkTicket(ticket);
        const data=await wait(()=>response.json(),controller.signal,Math.max(1,timeoutMs-(now()-start)));
        checkTicket(ticket);
        if(!response.ok){const e=error(classify(status));e.retryMs=retryDelay(response,data,now());e.status=status;throw e;}
        return options.validate(data,body,stage);
      }catch(e){if(controller.signal.aborted)e=controller.signal.reason||e;code=e.code||'AI_INVALID_RESPONSE';throw Object.assign(e,{code});}
      finally{clearTimeout(timer);signal?.removeEventListener('abort',cancel);controllers.delete(controller);options.onTiming?.({stage,model,elapsedMs:now()-start,outcome:code?'failed':'success',code,httpStatus:status,...trace});}
    }
    function failed(model,e){proofs.delete(model);if(active===model)active='';lastCode=e.code;states.set(model,{status:['AI_QUOTA_EXHAUSTED','AI_UPSTREAM_ERROR','AI_NETWORK_ERROR','AI_TIMEOUT'].includes(e.code)?'limited':'unavailable',code:e.code,until:now()+(e.retryMs||60000)});emit();}
    function scheduleRetry(){
      retryAt=0;
      if(checkRuns<config.maxCheckRuns&&lastCode!=='AI_AUTH_ERROR'){
        const waiting=[...states.values()].map(s=>s.until).filter(until=>until>now());
        retryAt=Math.max(now()+config.retryMs,waiting.length?Math.min(...waiting):0);
      }
    }
    function ensure(opts){
      opts=opts||{};sync();
      if(!context){lastCode='AI_AUTH_ERROR';emit();return Promise.reject(error(lastCode));}
      if(active&&valid(active)&&!opts.exclude?.has(active))return Promise.resolve(guard());
      if(checkPromise)return checkPromise;
      // Las interacciones de pantalla no pueden saltarse la pausa ni reiniciar el ciclo agotado.
      if(now()<retryAt||checkRuns>=config.maxCheckRuns){emit();return Promise.reject(error(lastCode||'AI_MODEL_UNAVAILABLE'));}
      checkRuns++;retryAt=0;
      const ticket={epoch,context},controller=new AbortController();controllers.add(controller);
      const budget=Math.min(config.checkMs,opts.timeoutMs||config.checkMs);
      const start=now(),timer=setTimeout(()=>controller.abort(error('AI_TIMEOUT')),budget);
      const promise=Promise.resolve().then(async()=>{
        try{
          checkTicket(ticket);
          const others=catalog.map(m=>m.id).filter(id=>id!==lastGood);
          // Si se acabó el presupuesto, la siguiente ronda alcanza los modelos aún no probados.
          let candidates=[lastGood,...others.filter(id=>!states.has(id)),...others.filter(id=>states.has(id))].filter(Boolean);
          candidates=candidates.filter(id=>!opts.exclude?.has(id)&&(states.get(id)?.until||0)<=now()).slice(0,config.maxCandidates);
          if(!candidates.length)throw error(lastCode||'AI_MODEL_UNAVAILABLE');
          // Una generación válida acredita soporte y cuota; listar modelos antes no lo acredita.
          const body=options.probeBody();
          for(const model of candidates){
            const remaining=budget-(now()-start);if(remaining<=0||controller.signal.aborted)throw error('AI_TIMEOUT');
            states.set(model,{status:'checking'});emit();
            try{
              await call(model,body,controller.signal,Math.min(config.attemptMs,remaining),'ai-precheck',ticket);
              checkTicket(ticket);if(controller.signal.aborted)throw error('AI_TIMEOUT');
              const at=now();proofs.set(model,{at,until:at+config.ttlMs,epoch});active=lastGood=model;lastCode='';checkRuns=retryAt=0;states.set(model,{status:'available'});emit();return guard();
            }catch(e){
              checkTicket(ticket);failed(model,e);
              if(controller.signal.aborted||!['AI_QUOTA_EXHAUSTED','AI_MODEL_UNAVAILABLE','AI_UPSTREAM_ERROR','AI_TIMEOUT','AI_NETWORK_ERROR','AI_INVALID_RESPONSE','AI_REQUEST_REJECTED'].includes(e.code))throw e;
            }
          }
          throw error(lastCode||'AI_MODEL_UNAVAILABLE');
        }catch(e){
          checkTicket(ticket);lastCode=e.code||'AI_INVALID_RESPONSE';
          scheduleRetry();
          emit();throw e;
        }
        finally{clearTimeout(timer);controllers.delete(controller);}
      });
      checkPromise=promise;emit();promise.then(()=>{if(checkPromise===promise){checkPromise=null;emit();}},()=>{if(checkPromise===promise){checkPromise=null;emit();}});
      return promise;
    }
    async function generate(body,opts){
      opts=opts||{};const start=now(),excluded=new Set(),attempts=[];
      let ticket=opts.ticket||await ensure();
      checkTicket(ticket);
      if(!valid(ticket.model))ticket=await ensure();
      for(let attempt=0;attempt<config.maxCandidates;attempt++){
        checkTicket(ticket);if(opts.signal?.aborted)throw error('AI_CANCELLED');
        const remaining=(opts.timeoutMs||45000)-(now()-start);if(remaining<=0)throw error('AI_TIMEOUT');
        try{
          // attemptMs limita la prueba sintética, no la lectura del documento completo.
          const result=await call(ticket.model,body,opts.signal,remaining,'ai-response',ticket);
          checkTicket(ticket);if(opts.signal?.aborted)throw error('AI_CANCELLED');
          const at=now();proofs.set(ticket.model,{at,until:at+config.ttlMs,epoch});active=lastGood=ticket.model;lastCode='';checkRuns=retryAt=0;states.set(ticket.model,{status:'available'});emit();
          attempts.push({model:ticket.model,outcome:'success'});return {data:result,model:ticket.model,attempts};
        }catch(e){
          checkTicket(ticket);if(opts.signal?.aborted)throw error('AI_CANCELLED');
          attempts.push({model:ticket.model,outcome:'failed',code:e.code});failed(ticket.model,e);excluded.add(ticket.model);
          if(attempt+1>=config.maxCandidates||!['AI_QUOTA_EXHAUSTED','AI_MODEL_UNAVAILABLE'].includes(e.code)){scheduleRetry();emit();e.analysisAttempts=attempts;throw e;}
          const left=(opts.timeoutMs||45000)-(now()-start);if(left<=0)throw error('AI_TIMEOUT');
          ticket=await ensure({exclude:excluded,timeoutMs:left});
          options.onSwitch?.(ticket.model);
        }
      }
      throw error('AI_MODEL_UNAVAILABLE');
    }
    return {snapshot,guard,ensure,generate,invalidate:()=>{reset();emit();},checkTicket};
  }
  return {catalog,create,classify,retryDelay};
});
