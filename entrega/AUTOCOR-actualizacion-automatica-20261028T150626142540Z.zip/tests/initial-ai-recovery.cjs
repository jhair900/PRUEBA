// Reproduce los fallos observados sin red, documentos ni credenciales reales.
const assert=require('node:assert/strict'),api=require('../js/gemini-availability.js');
const [A,B]=api.catalog.map(m=>m.id),ok=()=>({ok:true,status:200,json:async()=>({valid:true})});
const failure=(status=503,retryAfter='0',service='UNAVAILABLE',message='The service is temporarily unavailable.')=>({ok:false,status,retryAfter,json:async()=>({error:{code:status,status:service,message}})});
const tick=()=>new Promise(r=>setTimeout(r,0));
function setup(request,extra={}){
 let context='fixture-initial';const calls=[],timings=[],states=[];
 const controller=api.create({getContext:()=>context,config:{retryBaseMs:1,retryMaxMs:2,checkMs:200,attemptMs:40,...extra},probeBody:()=>({probe:true}),validate:d=>{if(!d.valid)throw Object.assign(Error('AI_INVALID_RESPONSE'),{code:'AI_INVALID_RESPONSE'});return d;},request:(model,body,signal)=>{calls.push({model,probe:!!body.probe});return request(model,body,signal,calls.length);},onTiming:t=>timings.push(t),onState:s=>states.push(s)});
 return {controller,calls,timings,states,context:c=>context=c};
}
(async()=>{
 const unhandled=[],onUnhandled=e=>unhandled.push(e);process.on('unhandledRejection',onUnhandled);
 try{
  let t=setup(async(model,body,signal,n)=>{if(n===1)throw Object.assign(Error('AI_TIMEOUT'),{code:'AI_TIMEOUT'});if(n===2)return failure();return ok();});
  const tickets=await Promise.all(Array.from({length:8},()=>t.controller.ensure()));
  assert.deepEqual(t.calls.map(v=>v.model),[A,B,A]);assert.ok(tickets.every(v=>v.model===A));assert.equal(t.controller.snapshot().ready,true);
  const count=t.calls.length;for(let i=0;i<5;i++)await t.controller.ensure();assert.equal(t.calls.length,count);
  await t.controller.generate({document:true});assert.equal(t.calls.at(-1).model,A);assert.equal(t.calls.filter(v=>v.probe).length,3);
  assert.equal(t.timings.find(v=>v.serviceCode===503).serviceMessage,'The service is temporarily unavailable.');
  console.log('OK timeout A → 503 B → recuperación acotada en la misma ronda; un solo inicio compartido y modelo fijo después');

  t=setup(async()=>failure());await assert.rejects(t.controller.ensure(),e=>e.code==='AI_UPSTREAM_ERROR');assert.equal(t.calls.length,4);assert.equal(t.controller.snapshot().ready,false);
  for(let i=0;i<3;i++)await assert.rejects(t.controller.ensure());t.controller.invalidate();await assert.rejects(t.controller.ensure());assert.equal(t.calls.length,4);
  console.log('OK servicio persistentemente caído: cuatro envíos como máximo; no hay temporizador periódico ni nuevas rondas por interacción');

  t=setup(async(model,body,signal,n)=>n<=2?failure(503,model===A?'60':'0'):ok());assert.equal((await t.controller.ensure()).model,B);assert.deepEqual(t.calls.map(v=>v.model),[A,B,B]);assert.ok(t.timings.some(t=>t.outcome==='skipped'));
  t=setup((m,b,signal)=>new Promise(()=>{}),{checkMs:30,attemptMs:8});await assert.rejects(t.controller.ensure(),e=>e.code==='AI_TIMEOUT');assert.ok(t.calls.length<=4);
  console.log('OK Retry-After se respeta sin exceder el plazo; el límite total también cancela una solicitud atascada');

  t=setup(async()=>failure(500,'0','CONFIG_ERROR','GEMINI_API_KEY no configurada en Script Properties'));await assert.rejects(t.controller.ensure(),e=>e.code==='AI_BACKEND_CONFIG_ERROR');assert.equal(t.calls.length,1);assert.equal(t.controller.snapshot().ready,false);
  t=setup(async()=>failure(429,'60','RESOURCE_EXHAUSTED'));await assert.rejects(t.controller.ensure(),e=>e.code==='AI_QUOTA_EXHAUSTED');assert.deepEqual(t.calls.map(v=>v.model),[A,B]);
  assert.equal(api.classify(403,{}, {statusOrigin:'apps-script-http'}),'AI_BACKEND_ACCESS_ERROR');assert.equal(api.classify(403,{error:{status:'PERMISSION_DENIED'}}),'AI_PROVIDER_AUTH_ERROR');
  console.log('OK sesión/proveedor/configuración/cuota/acceso al backend conservan diagnósticos distintos; no se acredita un modelo fallido');

  let releaseOld;
  t=setup((model,body,signal,n)=>n===1?new Promise(r=>releaseOld=r):Promise.resolve(ok()));
  const old=t.controller.ensure().catch(e=>e.code);await tick();t.context('');t.controller.invalidate();t.context('fixture-renewed');t.controller.invalidate();
  assert.equal(t.controller.snapshot().selectionStarted,false,'La recuperación no espera a que termine la promesa vieja');
  const renewed=t.controller.ensure();await old;const selected=await renewed;releaseOld(ok());await tick();
  assert.equal(selected.model,A);assert.equal(t.controller.snapshot().ready,true);assert.equal(t.calls.length,2);
  t.context('fixture-third');t.controller.invalidate();await t.controller.ensure();assert.equal(t.calls.length,2,'Una selección terminada no se repite al autenticar');
  console.log('OK autenticación interrumpida y recuperada antes de terminar la promesa anterior: continúa el inicio sin bloqueo ni respuestas tardías');

  const sanitized=api.safeDiagnostic('UNAVAILABLE Bearer token-secreto https://example.invalid/?key=oculta correo@example.test projects/mi-proyecto 123456789 AIzaClaveSecreta');
  for(const privateText of ['token-secreto','example.invalid','correo@example.test','mi-proyecto','123456789','AIzaClaveSecreta'])assert.ok(!sanitized.includes(privateText));
  assert.ok(!JSON.stringify(t.timings).includes('fixture-renewed'));await tick();assert.deepEqual(unhandled,[]);
  console.log('OK diagnóstico acotado sin credenciales ni identificadores; sin rechazos sin manejar');
 }finally{process.removeListener('unhandledRejection',onUnhandled);}
})().catch(e=>{console.error(e);process.exitCode=1;});
